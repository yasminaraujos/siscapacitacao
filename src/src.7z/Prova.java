import java.util.Scanner;

public class Prova {
    public static void main(String[] args) {
        Scanner enter = new Scanner(System.in);
        System.out.println("Entre com a senha");
        int teclado= enter.nextInt();
        int senha=123;
        while (teclado!= senha){
        System.out.println("senha invalida, tente novamente");
            System.out.println("Entre com a senha novamente");
         teclado=enter.nextInt();
        }
        System.out.println("Seja bem vindo");

    }
}