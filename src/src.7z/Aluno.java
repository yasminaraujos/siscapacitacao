import java.util.Scanner;

public class Aluno
{
    public static void main(String[] args)
    {
        Scanner enter = new Scanner(System.in);
        double nota1 = 0;
        double nota2 = 0;
        String nome;

        System.out.println("Entre com o nome do aluno");
        nome = enter.next();




        do
        {

            System.out.println("Entre com a primeira nota do aluno");
            nota1 = enter.nextDouble();
            if(nota1 <0 || nota1 >10){
                System.out.println("Nota inválida");
            }

        }while (nota1 < 0 || nota1 > 10);






        do
        {

            System.out.println("Entre com a segunda nota do aluno");
            nota2 = enter.nextDouble();
            if (nota2 <0 || nota2 >10){
                System.out.println("Nota inválida!!");
            }

        }while (nota2 < 0 || nota2 > 10);

        double media = (nota1 + nota2)/2;

        if(media >= 7)
        {
            System.out.println("Aprovado");
        }
        else if(media >5|| media<6.9)
        {
            System.out.println("Recuperação");
        }
        else
        {
            System.out.println("Reprovado");
        }

    }
}
